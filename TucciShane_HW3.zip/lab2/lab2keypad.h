/*----------------------------------------------------------------------------*/
/* Title:    lab2keypad.h - Defines and Macros for KEYPAD API.                */
/*----------------------------------------------------------------------------*/
/* Copyright (c) 2017 Lewis University.  All rights reserved.                 */
/* CPEN32000 Hardware and Software Systems, Spring 2017                        */
/*----------------------------------------------------------------------------*/
/* This library is implemented to be used with Tiva C Microcontrollers series.*/
/* It has been compile with Code Composer Studio.                             */
/*----------------------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/
/*--                                                 Date: 14th February 2017 */
/*-----------------------------------------------------------------------------*/

#ifndef __LAB2KEYPAD_H__
#define __LAB2KEYPAD_H__
//*****************************************************************************
//
// If building with a C++ compiler, make all of the definitions in this header
// have a C binding.
//
//*****************************************************************************
#ifdef __cplusplus
extern "C"
{
#endif


void keypad_pin_init(void);         // initialize GPIO pins for keypad

void delay_ms(unsigned int t);      // rudimentary delay millisecond function

void clear_row_output(void);        // clear PK 0, 1, 2, 3 output bits
void set_row_output(void);          // set PK 0, 1, 2, 3 output bits
void drive_row_low(char row);       // set all row bits except and clear specified row
signed char read_column_input(char col);

signed char map_key(signed char i); // map the row and column index to corresponding character
signed char get_key(void);          // scan in key press
char debounce(char col);            // debounce key press
void seg_Init(void);                // Initialization of PE0 to PE4 and PG0 as outputs for the 7-segement display

unsigned char bcd_7segchar(char stchar);    // Convert characters '0', '1'.......'9' to  7-segement codes
void GPIO_7Seg(unsigned char  disp_val);    // Send the 7-segment code to the GPIO




//*****************************************************************************
//
// Mark the end of the C bindings section for C++ compilers.
//
//*****************************************************************************
#ifdef __cplusplus
}
#endif

#endif // __LAB2KEYPAD_H__
