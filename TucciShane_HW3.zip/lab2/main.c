#include <stdint.h>
#include <stdbool.h>
#include "inc/tm4c129encpdt.h"
#include "inc/hw_memmap.h"
#include "inc/hw_types.h"
#include "driverlib/sysctl.h"
#include "driverlib/interrupt.h"
#include "driverlib/gpio.h"
#include "driverlib/timer.h"
#include "driverlib/adc.h"
#include "driverlib/debug.h"


void toggle_LED1()
{
    static uint32_t s =1; //next state of LED
    (s == 1) ? GPIOPinWrite(GPIO_PORTN_BASE, GPIO_PIN_0, 1) :  GPIOPinWrite(GPIO_PORTN_BASE, GPIO_PIN_0, 0);
    s = 1 -s; //toggle
}

void toggle_Temp()
{
    int temp = 0;
    char i = 0;
    char j = 0;
    char dig1, dig2, dig3, dig4;

    unsigned char  dispVal[4];
    uint32_t ui32SysClock;
    uint32_t ui32ADC0Value[1];
    volatile double Vmes;

    // Enable GPIO ports for 7 segment display
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOE);
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOG);
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOA);
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOC);

    seg_Init();

    // LA 5 - 2 ADC




    ui32SysClock = SysCtlClockFreqSet((SYSCTL_XTAL_25MHZ |
                                            SYSCTL_OSC_MAIN |
                                            SYSCTL_USE_PLL |
                                            SYSCTL_CFG_VCO_480), 20000000);


    SysCtlPeripheralEnable(SYSCTL_PERIPH_ADC0);
    ADCHardwareOversampleConfigure(ADC0_BASE, 64);
    ADCSequenceConfigure(ADC0_BASE, 3, ADC_TRIGGER_PROCESSOR, 0);
    ADCSequenceStepConfigure(ADC0_BASE, 3, 0, ADC_CTL_CH4 | ADC_CTL_IE | ADC_CTL_END);

    ADCSequenceEnable(ADC0_BASE, 3);
    ADCIntClear(ADC0_BASE, 3);

    while(1)
     {

        ADCIntClear(ADC0_BASE, 3);
        ADCProcessorTrigger(ADC0_BASE, 3);

        while(!ADCIntStatus(ADC0_BASE, 3, false))
        {
        }

        ADCSequenceDataGet(ADC0_BASE, 3, ui32ADC0Value);

        Vmes = ((double)*ui32ADC0Value/4095) * 3.3;



        SysCtlDelay(ui32SysClock / 12);

        temp =  Vmes*1000;

        dig1 = (temp / 1000);
        dig2 = (temp - (dig1 * 1000)) / 100;
        dig3 = (temp - ((dig1 * 1000) + (dig2 * 100))) / 10;
        dig4 = (temp - ((dig1 * 1000) + (dig2 * 100) + (dig3 * 10))) / 1;

        dispVal[0] = bcd_7segchar((char)(map_key(dig1)));
        dispVal[1] = bcd_7segchar((char)(map_key(dig2)));
        dispVal[2] = bcd_7segchar((char)(map_key(dig3)));
        dispVal[3] = bcd_7segchar((char)(map_key(dig4)));


        for (j = 0; j < 20; j++)
              {

                   for ( i = 0; i < 4; i++)
                   {
                               drive_AN(i);
                                  GPIOPinWrite(GPIO_PORTE_BASE, GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3 | GPIO_PIN_4 | GPIO_PIN_5, dispVal[i] & 0x3F );
                                  GPIOPinWrite(GPIO_PORTG_BASE, GPIO_PIN_0 ,  (dispVal[i] & 0x40)>>6);
                                  delay_ms(1000);
                   }
              }
     }
}


int main(void)
{


    uint32_t ui32Period;

    SysCtlClockFreqSet((SYSCTL_XTAL_25MHZ | SYSCTL_OSC_MAIN | SYSCTL_USE_PLL | SYSCTL_CFG_VCO_480), 40000000);

    SysCtlPeripheralEnable(SYSCTL_PERIPH_ADC0);
    ADCHardwareOversampleConfigure(ADC0_BASE, 64);
    ADCSequenceConfigure(ADC0_BASE, 3, ADC_TRIGGER_PROCESSOR, 0);
    ADCSequenceStepConfigure(ADC0_BASE, 3, 0, ADC_CTL_CH4 | ADC_CTL_IE | ADC_CTL_END);

    ADCSequenceEnable(ADC0_BASE, 3);
    ADCIntClear(ADC0_BASE, 3);


    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPION);
    GPIOPinTypeGPIOOutput(GPIO_PORTN_BASE, GPIO_PIN_0);

    SysCtlPeripheralEnable(SYSCTL_PERIPH_TIMER0);
    TimerConfigure(TIMER0_BASE, TIMER_CFG_PERIODIC);

    ui32Period = (SysCtlClockGet() / 0.1) / 2;
    TimerLoadSet(TIMER0_BASE, TIMER_A, ui32Period -1);

    IntEnable(INT_TIMER0A);
    TimerIntEnable(TIMER0_BASE, TIMER_TIMA_TIMEOUT);
    IntMasterEnable();
    TimerEnable(TIMER0_BASE, TIMER_A);

    while(1)
    {

    }
}

void Timer0IntHandler(void)
{
    //clear timer interrupt
    TimerIntClear(TIMER0_BASE, TIMER_TIMA_TIMEOUT);
    //read current state of the GPIO pin and
    //write back the opposite state
    toggle_LED1();
    toggle_Temp();
}


