#include <stdint.h>
#include <stdbool.h>
#include "inc/hw_memmap.h"
#include "driverlib/gpio.h"
#include "driverlib/sysctl.h"
#include "lab2keypad.h"



/*****************************************************************************
//
//! Scans the keypad by setting each row and reading the columns
//! to detect if any key has been pressed
//! \param none
//!
//! \return a signed value that will be used for the keypad map
//
*****************************************************************************/
int an = 0; //AN signal
int t = 0; //test
int x = 0;
unsigned char num[4];

// This takes the inputs
signed char get_key(void) {
    /* Add your code */
    /* You will have to debounce in order to make sure the key is stable*/

        int r;
        int c;

        for(r = 0; r < 4; r++) {
            drive_row_low(r);
            for (c = 0; c < 3; c++) {
                if (read_column_input(c) == 0) {
                    if (debounce(c)) {
                        return ((3 * r) + c);

                    }
                }
            }
        }
    return -1;
}


/*****************************************************************************
//
//! Debounces a key in order to remove glitches and have stable output when
//! a key his pressed
//! \param cloumn id
//!
//! \return a bool value to indicate whether a key was pressed or not.
//
*****************************************************************************/

char debounce(char col) {  /* Complete */
    char k;
    char counter = 0;               // number of times key is pressed
    char debounce_count = 10;    // threshold for good key pres

    // check key state ten times over ten milliseconds
    for (k = 0; k < 10; k++) {
        if (read_column_input(col) == 1 && counter > 0) {
            counter--;
        }
        if (read_column_input(col) == 0) {
            counter++;
        }
        delay_ms(5);
    }

    if (counter >= debounce_count) {
        return 1;
    }   else {
        return 0;
    }
}



/*****************************************************************************
//
//! Maps the row and column index to corresponding character
//! a key his pressed
//! \param cloumn id
//!
//! \return the key character
//
*****************************************************************************/
signed char map_key(signed char i) { /* Complete */
    char keys[12] = {'1', '2', '3', '4', '5', '6', '7', '8', '9', '*', '0', '#'};
    if (i > 11|| i < 0) {
        return -1;
    } else {
        return keys[i];
    }
}

/*****************************************************************************
//
//! Read a particular input pin specified by a column index to identify a key
//! \param cloumn id
//!
//! \return a signed value
//
*****************************************************************************/


signed char read_column_input(char col) {
    switch (col) {
        /* Add your code */
    // Cycles through the colums on the keypad.
    case 0:
        col = GPIOPinRead(GPIO_PORTM_BASE, GPIO_PIN_0); // column 1
        break;
    case 1:
        col = GPIOPinRead(GPIO_PORTM_BASE, GPIO_PIN_1); // column 2
        break;
    case 2:
        col = GPIOPinRead(GPIO_PORTM_BASE, GPIO_PIN_2); // column 3
        break;

    default:
        col = 1;
        break;
    }
    return col;
}


/*****************************************************************************
//
//! Set a particular row associed to an output pin to low for keypad scanning
//! \param row id
//!
//! \return none
//
*****************************************************************************/

void drive_row_low(char row) {
    set_row_output();
    // cycles through the rows on the keypad
    switch (row) {
        /* Add your code */
    case 0:
        GPIOPinWrite(GPIO_PORTK_BASE, GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3, 0X0E);// row1
        break;
    case 1:
        GPIOPinWrite(GPIO_PORTK_BASE, GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3, 0X0D);// row2
        break;
    case 2:
        GPIOPinWrite(GPIO_PORTK_BASE, GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3, 0X0B);// row3
        break;
    case 3:
        GPIOPinWrite(GPIO_PORTK_BASE, GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3, 0X07);// row4
        break;

    default:
        GPIOPinWrite(GPIO_PORTK_BASE, GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3, 0xF); // sets to 1111
        break;
    }
}

void drive_AN(char sig) {

    switch(sig) {
    case 0:
        GPIOPinWrite(GPIO_PORTC_BASE, GPIO_PIN_4 | GPIO_PIN_5 | GPIO_PIN_6 | GPIO_PIN_7, 0XE0);
        break;
    case 1:
        GPIOPinWrite(GPIO_PORTC_BASE, GPIO_PIN_4 | GPIO_PIN_5 | GPIO_PIN_6 | GPIO_PIN_7, 0XD0);
        break;
    case 2:
        GPIOPinWrite(GPIO_PORTC_BASE, GPIO_PIN_4 | GPIO_PIN_5 | GPIO_PIN_6 | GPIO_PIN_7, 0XB0);
        break;
    case 3:
        GPIOPinWrite(GPIO_PORTC_BASE, GPIO_PIN_4 | GPIO_PIN_5 | GPIO_PIN_6 | GPIO_PIN_7, 0X70);
        break;

    default:
        GPIOPinWrite(GPIO_PORTC_BASE, GPIO_PIN_4 | GPIO_PIN_5 | GPIO_PIN_6 | GPIO_PIN_7, 0XF0);
        break;
    }

}

// clear PK 0, 1, 2, 3 output bits
void clear_row_output(void) {
    GPIOPinWrite(GPIO_PORTK_BASE, GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3,  0x00 );


}
void clear_an_output(void) {
    GPIOPinWrite(GPIO_PORTL_BASE, GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3,  0x00 );
}

// set PK 0, 1, 2, 3 output bits
void set_row_output(void) {
    GPIOPinWrite(GPIO_PORTK_BASE,  GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3,  0x0F );
}

// rudimentary delay millisecond function
void delay_ms(unsigned int t) {
    unsigned int i, j;
    for (i = 0; i < t; i++) {
        for (j = 0; j < 2000; j++);
    }
}

// initialize GPIO pins for keypad
void keypad_pin_init(void) {

/* Add your code */

    // Set the PortM as Input and PortK as output
    GPIOPinTypeGPIOInput(GPIO_PORTM_BASE, GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_2); // column
    GPIOPinTypeGPIOOutput(GPIO_PORTK_BASE, GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3); // row
}

// Initialize the 7-segment display module
void seg_Init(void)
{
    /* Add your code */

    // Set the ports as outputs
    GPIOPinTypeGPIOOutput(GPIO_PORTE_BASE, GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3 | GPIO_PIN_4 | GPIO_PIN_5);
    GPIOPinTypeGPIOOutput(GPIO_PORTG_BASE, GPIO_PIN_0);
    GPIOPinTypeGPIOOutput(GPIO_PORTC_BASE, GPIO_PIN_4 | GPIO_PIN_5 | GPIO_PIN_6 | GPIO_PIN_7); // for transistor
}
/*****************************************************************************
//
// This function takes a char and generates its equivalent 7-segment patterns
// as an unsigned char.
 *
 */

unsigned char bcd_7segchar(char stchar)   /* This is complete no need of change*/
{
    unsigned char val;

    switch(stchar) {
          case '0' :
            val = 0x40;
             break;
          case '1' :
              val = 0x79;
               break;
          case '2' :
              val = 0x24;
              break;
          case '3' :
              val = 0x30;
             break;
          case '4' :
              val = 0x19;
             break;
          case '5' :
              val = 0x12;
              break;
          case '6' :
              val = 0x02;
              break;
          case '7' :
              val = 0x78;
              break;
          case '8' :
              val = 0x00;
              break;
          case '9' :
              val = 0x10;
              break;

          default :
              val = 0x00;
             break;
       }

       return val;


}

// Output display values to the 7-segment Module
void GPIO_7Seg(unsigned char  disp_val)
{
    /* Add your code */

    // cycles and stores inputs into an array (displays one number at a time)
    while (1) {
        num[x]= disp_val;
        // This delay allows for one input at a time.
        delay_ms(150);
            for (t = 0; t <= x; t++) {
                drive_AN(t);
                GPIOPinWrite(GPIO_PORTE_BASE, GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3 | GPIO_PIN_4 | GPIO_PIN_5, num[t] & 0x3F );
                GPIOPinWrite(GPIO_PORTG_BASE, GPIO_PIN_0 ,  (num[t] & 0x40)>>6);
            }
            x++;
            break;
        }
    // will loop infinitely once 4 inputs are entered. (displays all 4 numbers)
    if (x == 4) {
        while (t <= 4) {
            drive_AN(t);
            GPIOPinWrite(GPIO_PORTE_BASE, GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3 | GPIO_PIN_4 | GPIO_PIN_5, num[t] & 0x3F );
            GPIOPinWrite(GPIO_PORTG_BASE, GPIO_PIN_0 ,  (num[t] & 0x40)>>6);
            delay_ms(1);
            t++;

            if (t >= 4) {
                t = 0;
            }
        }
    }
}
